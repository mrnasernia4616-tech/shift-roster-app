package ir.substation.shift

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.os.Bundle
import android.content.Intent
import android.widget.*
import android.view.Gravity

class ShiftWidgetConfigActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }
        val prefs = getSharedPreferences("shift_roster", MODE_PRIVATE)
        val stations = prefs.getString("stations", "پست ۱").orEmpty().split("\n").filter { it.isNotBlank() }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(24,24,24,24) }
        root.addView(TextView(this).apply { text="پست مورد نظر برای ویجت"; textSize=20f; gravity=Gravity.CENTER })
        val spinner=Spinner(this); spinner.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, stations); root.addView(spinner)
        val btn=Button(this).apply { text="ثبت ویجت" }; root.addView(btn)
        btn.setOnClickListener {
            val station=spinner.selectedItem?.toString() ?: stations.first()
            getSharedPreferences("widget_stations", MODE_PRIVATE).edit().putString("station_$widgetId", station).apply()
            ShiftWidgetProvider.update(this, AppWidgetManager.getInstance(this), widgetId)
            val result=Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            setResult(RESULT_OK,result); finish()
        }
        setContentView(root)
    }
}
