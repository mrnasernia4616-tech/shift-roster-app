package ir.substation.shift

import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.ChronoUnit

/** A begins at 08:00 on the reference date; each group takes one 24-hour turn. */
object ShiftCycle {
    private val groups = listOf("A", "B", "C")

    fun groupAt(now: LocalDateTime, anchorDate: LocalDate = LocalDate.of(2026, 11, 20)): String {
        val anchor = anchorDate.atTime(8, 0)
        val elapsedSeconds = Duration.between(anchor, now).seconds
        val completedTurns = Math.floorDiv(elapsedSeconds, 86_400L)
        return groups[Math.floorMod(completedTurns, 3L).toInt()]
    }

    fun nextGroup(now: LocalDateTime, anchorDate: LocalDate = LocalDate.of(2026, 11, 20)): String {
        return groups[(groups.indexOf(groupAt(now, anchorDate)) + 1) % groups.size]
    }

    fun handover(now: LocalDateTime): LocalDateTime =
        if (now.toLocalTime() < LocalTime.of(8, 0)) now.toLocalDate().atTime(8, 0)
        else now.toLocalDate().plusDays(1).atTime(8, 0)

    fun upcoming(now: LocalDateTime, anchorDate: LocalDate = LocalDate.of(2026, 11, 20)): List<Pair<LocalDate, String>> =
        (0..6).map { offset ->
            val date = now.toLocalDate().plusDays(offset.toLong())
            val evaluation = if (offset == 0) now else date.atTime(8, 0)
            date to groupAt(evaluation, anchorDate)
        }
}
