package ir.substation.shift

import android.app.Activity
import android.os.Bundle
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.text.InputType
import java.time.LocalDateTime
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : Activity() {
 private val prefs by lazy { getSharedPreferences("shift_roster", MODE_PRIVATE) }
 private var stations = mutableListOf<String>()
 private lateinit var selector: Spinner
 private lateinit var stationInput: EditText
 private lateinit var anchorInput: EditText
 private lateinit var membersA: EditText; private lateinit var membersB: EditText; private lateinit var membersC: EditText
 private lateinit var summary: TextView; private lateinit var schedule: TextView
 private var loading = false
 private fun key(station:String, group:String) = "${station}_$group"
 private fun anchorKey(station:String) = "${station}_anchor"
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  stations = prefs.getString("stations", "پست ۱").orEmpty().split("\n").filter{it.isNotBlank()}.toMutableList().ifEmpty { mutableListOf("پست ۱") }
  buildUi()
 }
 private fun buildUi(){
  val scroll=ScrollView(this); val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24); layoutDirection=LinearLayout.LAYOUT_DIRECTION_RTL}
  scroll.addView(root); setContentView(scroll)
  root.addView(label("مدیریت شیفت پست‌های برق",24,true))
  root.addView(label("چرخه ۲۴ ساعت کار / ۴۸ ساعت استراحت — تحویل ساعت ۰۸:۰۰",16,false))
  selector=Spinner(this); root.addView(selector); refreshStations()
  stationInput=edit("نام پست"); root.addView(stationInput)
  root.addView(button("افزودن پست") { val n=stationInput.text.toString().trim(); if(n.isNotEmpty() && !stations.contains(n) && stations.size < 25){ stations.add(n); saveStations(); refreshStations(); selector.setSelection(stations.lastIndex); stationInput.setText("") } else toast(if(stations.size >= 25) "حداکثر ۲۵ پست قابل ثبت است" else "نام خالی یا تکراری است") })
  root.addView(button("تغییر نام پست منتخب") { renameStation() })
  root.addView(button("حذف پست منتخب") { deleteStation() })
  summary=label("",18,true); root.addView(summary)
  root.addView(label("تاریخ مرجع شروع گروه A (yyyy-MM-dd)",15,true)); anchorInput=edit("2026-11-20"); anchorInput.inputType=InputType.TYPE_CLASS_TEXT; root.addView(anchorInput)
  root.addView(button("ذخیره تاریخ مرجع") { saveAnchor(); updateSummary() })
  root.addView(label("اعضای گروه A (هر نفر در یک خط)",16,true)); membersA=edit("نام اعضای گروه A"); root.addView(membersA)
  root.addView(label("اعضای گروه B",16,true)); membersB=edit("نام اعضای گروه B"); root.addView(membersB)
  root.addView(label("اعضای گروه C",16,true)); membersC=edit("نام اعضای گروه C"); root.addView(membersC)
  root.addView(button("ذخیره نفرات") { saveMembers(); updateSummary() })
  schedule=label("",16,false); root.addView(schedule)
  selector.onItemSelectedListener=object: android.widget.AdapterView.OnItemSelectedListener { override fun onNothingSelected(parent:android.widget.AdapterView<*>?){}; override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:android.view.View?,position:Int,id:Long){ if(!loading){ loadMembers(); updateSummary() } } }
  loadMembers(); updateSummary()
  val liveWatcher = object : android.text.TextWatcher {
   override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int) {}
   override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) { if(!loading) updateSummary() }
   override fun afterTextChanged(s:android.text.Editable?) {}
  }
  membersA.addTextChangedListener(liveWatcher); membersB.addTextChangedListener(liveWatcher); membersC.addTextChangedListener(liveWatcher)
  anchorInput.addTextChangedListener(object : android.text.TextWatcher {
   override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int) {}
   override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) { if(!loading) updateSummary() }
   override fun afterTextChanged(s:android.text.Editable?) {}
  })
 }
 private fun selected()= if(::selector.isInitialized && selector.selectedItem!=null) selector.selectedItem.toString() else stations.firstOrNull().orEmpty()
 private fun saveStations(){ prefs.edit().putString("stations",stations.joinToString("\n")).apply(); refreshWidgets() }
 private fun refreshStations(){ loading=true; selector.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,stations); loading=false }
 private fun loadMembers(){ val s=selected(); loading=true; membersA.setText(prefs.getString(key(s,"A"),"")); membersB.setText(prefs.getString(key(s,"B"),"")); membersC.setText(prefs.getString(key(s,"C"),"")); if(::anchorInput.isInitialized) anchorInput.setText(prefs.getString(anchorKey(s),"2026-11-20")); loading=false }
 private fun saveMembers(){ val s=selected(); val raw=anchorInput.text.toString().trim(); val ed=prefs.edit().putString(key(s,"A"),membersA.text.toString()).putString(key(s,"B"),membersB.text.toString()).putString(key(s,"C"),membersC.text.toString()); try { LocalDate.parse(raw); ed.putString(anchorKey(s),raw) } catch(_:Exception) { toast("تاریخ مرجع نامعتبر است؛ تاریخ قبلی حفظ شد") }; ed.apply(); refreshWidgets(); toast("نفرات ذخیره شدند") }
 private fun saveAnchor(){ val s=selected(); val raw=anchorInput.text.toString().trim(); try { LocalDate.parse(raw); prefs.edit().putString(anchorKey(s),raw).apply(); refreshWidgets(); updateSummary(); toast("تاریخ مرجع ذخیره شد") } catch(e:Exception){toast("تاریخ را به شکل 2026-11-20 وارد کنید")} }
 private fun anchorDate():LocalDate { val s=selected(); return try{LocalDate.parse(prefs.getString(anchorKey(s),anchorInput.text.toString()) ?: "2026-11-20")}catch(e:Exception){LocalDate.of(2026,11,20)} }
 private fun renameStation(){ val old=selected(); val n=stationInput.text.toString().trim(); if(n.isBlank()||stations.contains(n)){toast("نام جدید خالی یا تکراری است");return}; val i=stations.indexOf(old); if(i<0)return; stations[i]=n; val ed=prefs.edit(); listOf("A","B","C").forEach{g->ed.putString(key(n,g),prefs.getString(key(old,g),""));ed.remove(key(old,g))}; ed.putString(anchorKey(n),prefs.getString(anchorKey(old),"2026-11-20")); ed.remove(anchorKey(old)); ed.apply(); saveStations(); refreshStations(); selector.setSelection(i); stationInput.setText(""); loadMembers(); updateSummary(); toast("نام پست تغییر کرد") }
 private fun deleteStation(){ if(stations.size<=1){toast("حداقل یک پست باید باقی بماند");return}; val s=selected(); val i=stations.indexOf(s); stations.remove(s); val ed=prefs.edit(); listOf("A","B","C").forEach{ed.remove(key(s,it))}; ed.remove(anchorKey(s)); ed.apply(); saveStations(); refreshStations(); selector.setSelection((i.coerceAtMost(stations.lastIndex))); loadMembers(); updateSummary(); toast("پست حذف شد") }
 private fun updateSummary(){ if(!::summary.isInitialized)return; val now=LocalDateTime.now(); val s=selected(); val a=try { LocalDate.parse(anchorInput.text.toString().trim()) } catch(e:Exception) { anchorDate() }; val current=ShiftCycle.groupAt(now,a); val next=ShiftCycle.nextGroup(now,a); val members=when(current){"A"->membersA.text.toString();"B"->membersB.text.toString();else->membersC.text.toString()}; val nextMembers=when(next){"A"->membersA.text.toString();"B"->membersB.text.toString();else->membersC.text.toString()}; summary.text="پست: $s\n\nگروه حاضر: $current\nتعداد نفرات حاضر: ${members.lines().count{it.trim().isNotEmpty()}}\nنفرات حاضر:\n${members.ifBlank{"(ثبت نشده)"}}\n\nگروه بعدی: $next\nتعداد نفرات گروه بعدی: ${nextMembers?.lines()?.count{it.trim().isNotEmpty()} ?: 0}\nنفرات گروه بعدی:\n${nextMembers?.ifBlank{"(ثبت نشده)"} ?: "(ثبت نشده)"}"
  schedule.text="برنامه ۷ روز آینده:\n"+ShiftCycle.upcoming(now,a).joinToString("\n"){ "${it.first.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))}: گروه ${it.second}" }
 }

 private fun refreshWidgets(){
  try { val manager=AppWidgetManager.getInstance(this); val ids=manager.getAppWidgetIds(ComponentName(this,ShiftWidgetProvider::class.java)); ids.forEach { ShiftWidgetProvider.update(this,manager,it) } } catch(_:Exception){}
 }
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
 private fun label(text:String,size:Int,bold:Boolean)=TextView(this).apply{this.text=text; textSize=size.toFloat(); setTextColor(Color.rgb(30,40,50)); if(bold)setTypeface(null,android.graphics.Typeface.BOLD); setPadding(0,12,0,12)}
 private fun edit(hint:String)=EditText(this).apply{this.hint=hint; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines=2; gravity=Gravity.TOP or Gravity.RIGHT}
 private fun button(text:String,action:()->Unit)=Button(this).apply{this.text=text; setOnClickListener{action()}}
}
