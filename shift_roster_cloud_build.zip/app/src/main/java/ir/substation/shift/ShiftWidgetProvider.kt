package ir.substation.shift

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class ShiftWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = updateAll(context, manager, ids)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_DATE_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val manager = AppWidgetManager.getInstance(context)
            updateAll(context, manager, manager.getAppWidgetIds(ComponentName(context, ShiftWidgetProvider::class.java)))
        }
    }
    companion object {
        const val ACTION_REFRESH = "ir.substation.shift.REFRESH_ROSTER_WIDGET"
        fun updateAll(context: Context, manager: AppWidgetManager, ids: IntArray) {
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.shift_widget)
                val serviceIntent = Intent(context, ShiftWidgetService::class.java).apply { putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id) }
                views.setRemoteAdapter(R.id.widget_list, serviceIntent)
                views.setTextViewText(R.id.widget_header, "وضعیت شیفت پست‌ها — گروه حاضر و بعدی")
                manager.updateAppWidget(id, views)
                manager.notifyAppWidgetViewDataChanged(id, R.id.widget_list)
            }
        }
        fun update(context: Context, manager: AppWidgetManager, id: Int) = updateAll(context, manager, intArrayOf(id))
    }
}
