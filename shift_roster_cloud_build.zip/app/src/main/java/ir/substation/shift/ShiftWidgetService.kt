package ir.substation.shift

import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import java.time.LocalDate
import java.time.LocalDateTime

class ShiftWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = RosterFactory(applicationContext)

    private class RosterFactory(private val context: Context) : RemoteViewsFactory {
        private val rows = mutableListOf<Pair<String, String>>()
        override fun onCreate() = Unit
        override fun onDataSetChanged() {
            rows.clear()
            val prefs = context.getSharedPreferences("shift_roster", Context.MODE_PRIVATE)
            val stations = prefs.getString("stations", "پست ۱").orEmpty().split("\n").filter { it.isNotBlank() }.take(25)
            val now = LocalDateTime.now()
            stations.forEach { station ->
                val anchor = try { LocalDate.parse(prefs.getString("${station}_anchor", "2026-11-20")) } catch (_: Exception) { LocalDate.of(2026, 11, 20) }
                val group = ShiftCycle.groupAt(now, anchor)
                val people = prefs.getString("${station}_$group", "").orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("، ").ifBlank { "نفرات ثبت نشده" }
                val next = ShiftCycle.nextGroup(now, anchor)
                val nextPeople = prefs.getString("${station}_$next", "").orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("، ").ifBlank { "نفرات ثبت نشده" }
                rows.add(station to "حاضر: گروه $group | $people\nبعدی: گروه $next | $nextPeople")
            }
        }
        override fun getCount() = rows.size
        override fun getViewAt(position: Int): RemoteViews {
            val (station, details) = rows.getOrElse(position) { "" to "" }
            return RemoteViews(context.packageName, R.layout.shift_widget_row).apply {
                setTextViewText(R.id.row_station, station)
                setTextViewText(R.id.row_details, details)
            }
        }
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = position.toLong()
        override fun hasStableIds() = true
        override fun onDestroy() = Unit
    }
}
